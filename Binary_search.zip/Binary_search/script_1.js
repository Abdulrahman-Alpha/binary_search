//BinarySearch
let recursiveFunction = function (array, Target, start, end)
 {
      
    // if false that mean the array not sorted or start point is end .
    if (start > end) return -1;
  
    // Find the middle index.
    let mid=Math.floor((start + end)/2);
  
    // Compare mid with given key Target
    if (array[mid]===Target) return mid;
         
    // If element at mid is greater than x,
    // search in the left half of mid
    if(array[mid] > Target)
        return recursiveFunction(array, x, start, mid-1);
    else
 
        // If element at mid is smaller than x,
        // search in the right half of mid
        return recursiveFunction(array, x, mid+1, end);
}
//arr is your array of elements that you want to search in
// your array of elements and target element
let arr = [1, 3, 5, 7, 8, 9];
let Target = 5;
//----------------------------------------------------------------
if (recursiveFunction(arr, Target, 0, arr.length-1) != -1)
    console.log("Element found!\n" + "and position of element is " + recursiveFunction(arr, Target, 0, arr.length-1) );
else console.log("Element not found!"); 
//-------------------------------
// developed by abdulrahman(alpha).